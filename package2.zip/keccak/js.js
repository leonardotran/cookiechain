module.exports = require('./lib/api')(require('./lib/keccak'))
